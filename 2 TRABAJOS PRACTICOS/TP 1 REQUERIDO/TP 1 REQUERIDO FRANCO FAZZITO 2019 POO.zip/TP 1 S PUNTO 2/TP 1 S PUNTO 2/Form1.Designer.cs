﻿namespace TP_1_S_PUNTO_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.DNITITULAR2 = new System.Windows.Forms.TextBox();
            this.button17 = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.IDCUENTA2 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.DNITITULAR1 = new System.Windows.Forms.TextBox();
            this.button18 = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.IDCUENTA1 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.ID1 = new System.Windows.Forms.TextBox();
            this.DINERO_CUENTA1 = new System.Windows.Forms.TextBox();
            this.DINERO_DESCUBIERTO1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ID4 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.ID_ORIGEN3 = new System.Windows.Forms.TextBox();
            this.DINERO_DESCUBIERTO3 = new System.Windows.Forms.TextBox();
            this.ID_DESTINO3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.DINERO_CUENTA3 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.ID2 = new System.Windows.Forms.TextBox();
            this.DINERO_CUENTA2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ID6 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.ID5 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.ID_DESTINO5 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.DINERO_CUENTA5 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.movimientos = new System.Windows.Forms.GroupBox();
            this.label25 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.CANTIDAD_DINERO11 = new System.Windows.Forms.TextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.ID11 = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.CANTIDAD_DINERO10 = new System.Windows.Forms.TextBox();
            this.ID_ORIGEN7 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.DCANTIDAD_DINERO7 = new System.Windows.Forms.TextBox();
            this.ID10 = new System.Windows.Forms.TextBox();
            this.ID_DESTINO7 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.CANTIDAD_DINERO9 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.ID9 = new System.Windows.Forms.TextBox();
            this.ID_ORIGEN8 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.CANTIDAD_DINERO8 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.ID_DESTINO8 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.GRID_CUENTAS_TITULARES = new System.Windows.Forms.DataGridView();
            this.GRID_CUENTAS = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.DNI_TITULAR2 = new System.Windows.Forms.TextBox();
            this.button16 = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.ID_CUENTA2 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.DNI_TITULAR1 = new System.Windows.Forms.TextBox();
            this.button15 = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.ID_CUENTA1 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.GRID_TITULAR_CUENTA = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.DNI3 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.DNI_ORIGEN2 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.NOMBRE2 = new System.Windows.Forms.TextBox();
            this.APELLIDO2 = new System.Windows.Forms.TextBox();
            this.DNI2 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.COMBO2 = new System.Windows.Forms.ComboBox();
            this.COMBO1 = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.NOMBRE1 = new System.Windows.Forms.TextBox();
            this.APELLIDO1 = new System.Windows.Forms.TextBox();
            this.DNI1 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.GRID_TITULARES = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.movimientos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GRID_CUENTAS_TITULARES)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GRID_CUENTAS)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GRID_TITULAR_CUENTA)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GRID_TITULARES)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1313, 634);
            this.tabControl1.TabIndex = 68;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.DimGray;
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.movimientos);
            this.tabPage1.Controls.Add(this.GRID_CUENTAS_TITULARES);
            this.tabPage1.Controls.Add(this.GRID_CUENTAS);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1305, 608);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "CUENTAS";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox5.Controls.Add(this.DNITITULAR2);
            this.groupBox5.Controls.Add(this.button17);
            this.groupBox5.Controls.Add(this.label41);
            this.groupBox5.Controls.Add(this.IDCUENTA2);
            this.groupBox5.Controls.Add(this.label42);
            this.groupBox5.Controls.Add(this.DNITITULAR1);
            this.groupBox5.Controls.Add(this.button18);
            this.groupBox5.Controls.Add(this.label43);
            this.groupBox5.Controls.Add(this.IDCUENTA1);
            this.groupBox5.Controls.Add(this.label44);
            this.groupBox5.Location = new System.Drawing.Point(957, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(326, 235);
            this.groupBox5.TabIndex = 107;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "MANEJO TITULAR CUENTA";
            // 
            // DNITITULAR2
            // 
            this.DNITITULAR2.Location = new System.Drawing.Point(202, 104);
            this.DNITITULAR2.Name = "DNITITULAR2";
            this.DNITITULAR2.Size = new System.Drawing.Size(100, 20);
            this.DNITITULAR2.TabIndex = 76;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(6, 78);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 52);
            this.button17.TabIndex = 73;
            this.button17.Text = "eliminar titular";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.Button17_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(199, 87);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(75, 13);
            this.label41.TabIndex = 77;
            this.label41.Text = "DNI TITULAR";
            // 
            // IDCUENTA2
            // 
            this.IDCUENTA2.Location = new System.Drawing.Point(92, 104);
            this.IDCUENTA2.Name = "IDCUENTA2";
            this.IDCUENTA2.Size = new System.Drawing.Size(100, 20);
            this.IDCUENTA2.TabIndex = 74;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(89, 87);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(65, 13);
            this.label42.TabIndex = 75;
            this.label42.Text = "ID CUENTA";
            // 
            // DNITITULAR1
            // 
            this.DNITITULAR1.Location = new System.Drawing.Point(202, 45);
            this.DNITITULAR1.Name = "DNITITULAR1";
            this.DNITITULAR1.Size = new System.Drawing.Size(100, 20);
            this.DNITITULAR1.TabIndex = 71;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(6, 19);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(75, 52);
            this.button18.TabIndex = 69;
            this.button18.Text = "añadir titular";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.Button18_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(199, 28);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(75, 13);
            this.label43.TabIndex = 72;
            this.label43.Text = "DNI TITULAR";
            // 
            // IDCUENTA1
            // 
            this.IDCUENTA1.Location = new System.Drawing.Point(92, 45);
            this.IDCUENTA1.Name = "IDCUENTA1";
            this.IDCUENTA1.Size = new System.Drawing.Size(100, 20);
            this.IDCUENTA1.TabIndex = 69;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(89, 28);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(65, 13);
            this.label44.TabIndex = 70;
            this.label44.Text = "ID CUENTA";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.ID1);
            this.groupBox2.Controls.Add(this.DINERO_CUENTA1);
            this.groupBox2.Controls.Add(this.DINERO_DESCUBIERTO1);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.ID4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.ID_ORIGEN3);
            this.groupBox2.Controls.Add(this.DINERO_DESCUBIERTO3);
            this.groupBox2.Controls.Add(this.ID_DESTINO3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.DINERO_CUENTA3);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(3, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(527, 235);
            this.groupBox2.TabIndex = 105;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "CRUD CUENTAS CORRIENTES";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(21, 37);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 52);
            this.button1.TabIndex = 38;
            this.button1.Text = "añadir cuenta corriente";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click_1);
            // 
            // ID1
            // 
            this.ID1.Location = new System.Drawing.Point(105, 54);
            this.ID1.Name = "ID1";
            this.ID1.Size = new System.Drawing.Size(100, 20);
            this.ID1.TabIndex = 39;
            // 
            // DINERO_CUENTA1
            // 
            this.DINERO_CUENTA1.Location = new System.Drawing.Point(211, 54);
            this.DINERO_CUENTA1.Name = "DINERO_CUENTA1";
            this.DINERO_CUENTA1.Size = new System.Drawing.Size(100, 20);
            this.DINERO_CUENTA1.TabIndex = 40;
            // 
            // DINERO_DESCUBIERTO1
            // 
            this.DINERO_DESCUBIERTO1.Location = new System.Drawing.Point(317, 54);
            this.DINERO_DESCUBIERTO1.Name = "DINERO_DESCUBIERTO1";
            this.DINERO_DESCUBIERTO1.Size = new System.Drawing.Size(100, 20);
            this.DINERO_DESCUBIERTO1.TabIndex = 41;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(102, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 42;
            this.label1.Text = "ID";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(102, 172);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(18, 13);
            this.label10.TabIndex = 61;
            this.label10.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(208, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 13);
            this.label2.TabIndex = 43;
            this.label2.Text = "DINERO CUENTA";
            // 
            // ID4
            // 
            this.ID4.Location = new System.Drawing.Point(105, 189);
            this.ID4.Name = "ID4";
            this.ID4.Size = new System.Drawing.Size(100, 20);
            this.ID4.TabIndex = 60;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(314, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 26);
            this.label3.TabIndex = 44;
            this.label3.Text = "DINERO \r\nDESCUBIERTO";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(21, 172);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 52);
            this.button4.TabIndex = 59;
            this.button4.Text = "modificar cuenta corriente";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Button4_Click_1);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(21, 104);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 52);
            this.button3.TabIndex = 50;
            this.button3.Text = "modificar cuenta corriente";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Button3_Click_1);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(208, 104);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 13);
            this.label9.TabIndex = 58;
            this.label9.Text = "ID DESTINO";
            // 
            // ID_ORIGEN3
            // 
            this.ID_ORIGEN3.Location = new System.Drawing.Point(102, 120);
            this.ID_ORIGEN3.Name = "ID_ORIGEN3";
            this.ID_ORIGEN3.Size = new System.Drawing.Size(100, 20);
            this.ID_ORIGEN3.TabIndex = 51;
            // 
            // DINERO_DESCUBIERTO3
            // 
            this.DINERO_DESCUBIERTO3.Location = new System.Drawing.Point(420, 120);
            this.DINERO_DESCUBIERTO3.Name = "DINERO_DESCUBIERTO3";
            this.DINERO_DESCUBIERTO3.Size = new System.Drawing.Size(100, 20);
            this.DINERO_DESCUBIERTO3.TabIndex = 57;
            // 
            // ID_DESTINO3
            // 
            this.ID_DESTINO3.Location = new System.Drawing.Point(208, 120);
            this.ID_DESTINO3.Name = "ID_DESTINO3";
            this.ID_DESTINO3.Size = new System.Drawing.Size(100, 20);
            this.ID_DESTINO3.TabIndex = 52;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(417, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 26);
            this.label4.TabIndex = 56;
            this.label4.Text = "DINERO \r\nDESCUBIERTO";
            // 
            // DINERO_CUENTA3
            // 
            this.DINERO_CUENTA3.Location = new System.Drawing.Point(314, 120);
            this.DINERO_CUENTA3.Name = "DINERO_CUENTA3";
            this.DINERO_CUENTA3.Size = new System.Drawing.Size(100, 20);
            this.DINERO_CUENTA3.TabIndex = 53;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(314, 103);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 13);
            this.label7.TabIndex = 55;
            this.label7.Text = "DINERO CUENTA";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(99, 103);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 13);
            this.label8.TabIndex = 54;
            this.label8.Text = "ID ORIGEN";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.ID2);
            this.groupBox1.Controls.Add(this.DINERO_CUENTA2);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.ID6);
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Controls.Add(this.ID5);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.ID_DESTINO5);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.DINERO_CUENTA5);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Location = new System.Drawing.Point(536, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(415, 234);
            this.groupBox1.TabIndex = 104;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "CRUD CAJAS AHORRO";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(14, 28);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 52);
            this.button2.TabIndex = 45;
            this.button2.Text = "añadir caja ahorro";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // ID2
            // 
            this.ID2.Location = new System.Drawing.Point(98, 45);
            this.ID2.Name = "ID2";
            this.ID2.Size = new System.Drawing.Size(100, 20);
            this.ID2.TabIndex = 46;
            // 
            // DINERO_CUENTA2
            // 
            this.DINERO_CUENTA2.Location = new System.Drawing.Point(204, 45);
            this.DINERO_CUENTA2.Name = "DINERO_CUENTA2";
            this.DINERO_CUENTA2.Size = new System.Drawing.Size(100, 20);
            this.DINERO_CUENTA2.TabIndex = 47;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(95, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(18, 13);
            this.label6.TabIndex = 48;
            this.label6.Text = "ID";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(95, 163);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(18, 13);
            this.label15.TabIndex = 71;
            this.label15.Text = "ID";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(201, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 13);
            this.label5.TabIndex = 49;
            this.label5.Text = "DINERO CUENTA";
            // 
            // ID6
            // 
            this.ID6.Location = new System.Drawing.Point(98, 180);
            this.ID6.Name = "ID6";
            this.ID6.Size = new System.Drawing.Size(100, 20);
            this.ID6.TabIndex = 70;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(13, 95);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 52);
            this.button5.TabIndex = 62;
            this.button5.Text = "modificar caja ahorro\r\n";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(14, 163);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 52);
            this.button6.TabIndex = 69;
            this.button6.Text = "eliminar caja ahorro\r\n";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.Button6_Click);
            // 
            // ID5
            // 
            this.ID5.Location = new System.Drawing.Point(94, 111);
            this.ID5.Name = "ID5";
            this.ID5.Size = new System.Drawing.Size(100, 20);
            this.ID5.TabIndex = 63;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(200, 95);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(69, 13);
            this.label11.TabIndex = 68;
            this.label11.Text = "ID DESTINO";
            // 
            // ID_DESTINO5
            // 
            this.ID_DESTINO5.Location = new System.Drawing.Point(200, 111);
            this.ID_DESTINO5.Name = "ID_DESTINO5";
            this.ID_DESTINO5.Size = new System.Drawing.Size(100, 20);
            this.ID_DESTINO5.TabIndex = 64;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(306, 94);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(96, 13);
            this.label13.TabIndex = 67;
            this.label13.Text = "DINERO CUENTA";
            // 
            // DINERO_CUENTA5
            // 
            this.DINERO_CUENTA5.Location = new System.Drawing.Point(306, 111);
            this.DINERO_CUENTA5.Name = "DINERO_CUENTA5";
            this.DINERO_CUENTA5.Size = new System.Drawing.Size(100, 20);
            this.DINERO_CUENTA5.TabIndex = 65;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(91, 94);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(63, 13);
            this.label14.TabIndex = 66;
            this.label14.Text = "ID ORIGEN";
            // 
            // movimientos
            // 
            this.movimientos.BackColor = System.Drawing.Color.DarkGray;
            this.movimientos.Controls.Add(this.label25);
            this.movimientos.Controls.Add(this.button7);
            this.movimientos.Controls.Add(this.CANTIDAD_DINERO11);
            this.movimientos.Controls.Add(this.button8);
            this.movimientos.Controls.Add(this.label26);
            this.movimientos.Controls.Add(this.button9);
            this.movimientos.Controls.Add(this.ID11);
            this.movimientos.Controls.Add(this.button10);
            this.movimientos.Controls.Add(this.label23);
            this.movimientos.Controls.Add(this.button11);
            this.movimientos.Controls.Add(this.CANTIDAD_DINERO10);
            this.movimientos.Controls.Add(this.ID_ORIGEN7);
            this.movimientos.Controls.Add(this.label24);
            this.movimientos.Controls.Add(this.DCANTIDAD_DINERO7);
            this.movimientos.Controls.Add(this.ID10);
            this.movimientos.Controls.Add(this.ID_DESTINO7);
            this.movimientos.Controls.Add(this.label22);
            this.movimientos.Controls.Add(this.label17);
            this.movimientos.Controls.Add(this.CANTIDAD_DINERO9);
            this.movimientos.Controls.Add(this.label16);
            this.movimientos.Controls.Add(this.label21);
            this.movimientos.Controls.Add(this.label12);
            this.movimientos.Controls.Add(this.ID9);
            this.movimientos.Controls.Add(this.ID_ORIGEN8);
            this.movimientos.Controls.Add(this.label18);
            this.movimientos.Controls.Add(this.CANTIDAD_DINERO8);
            this.movimientos.Controls.Add(this.label19);
            this.movimientos.Controls.Add(this.ID_DESTINO8);
            this.movimientos.Controls.Add(this.label20);
            this.movimientos.Location = new System.Drawing.Point(820, 246);
            this.movimientos.Name = "movimientos";
            this.movimientos.Size = new System.Drawing.Size(445, 348);
            this.movimientos.TabIndex = 103;
            this.movimientos.TabStop = false;
            this.movimientos.Text = "MOVIMIENTOS";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(226, 251);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(107, 13);
            this.label25.TabIndex = 132;
            this.label25.Text = "CANTIDAD DINERO";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(28, 19);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(90, 52);
            this.button7.TabIndex = 104;
            this.button7.Text = "transferencia cuenta corriente";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.Button7_Click);
            // 
            // CANTIDAD_DINERO11
            // 
            this.CANTIDAD_DINERO11.Location = new System.Drawing.Point(229, 268);
            this.CANTIDAD_DINERO11.Name = "CANTIDAD_DINERO11";
            this.CANTIDAD_DINERO11.Size = new System.Drawing.Size(100, 20);
            this.CANTIDAD_DINERO11.TabIndex = 131;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(28, 135);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(90, 52);
            this.button8.TabIndex = 105;
            this.button8.Text = "deposito";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.Button8_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(124, 251);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(18, 13);
            this.label26.TabIndex = 130;
            this.label26.Text = "ID";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(28, 193);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(90, 52);
            this.button9.TabIndex = 106;
            this.button9.Text = "extraccion cuenta corriente";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.Button9_Click);
            // 
            // ID11
            // 
            this.ID11.Location = new System.Drawing.Point(127, 268);
            this.ID11.Name = "ID11";
            this.ID11.Size = new System.Drawing.Size(100, 20);
            this.ID11.TabIndex = 129;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(28, 251);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(90, 52);
            this.button10.TabIndex = 107;
            this.button10.Text = "extraccion caja ahorro";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.Button10_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(226, 193);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(107, 13);
            this.label23.TabIndex = 128;
            this.label23.Text = "CANTIDAD DINERO";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(28, 77);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(90, 52);
            this.button11.TabIndex = 108;
            this.button11.Text = "transferencia caja ahorro";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.Button11_Click);
            // 
            // CANTIDAD_DINERO10
            // 
            this.CANTIDAD_DINERO10.Location = new System.Drawing.Point(229, 210);
            this.CANTIDAD_DINERO10.Name = "CANTIDAD_DINERO10";
            this.CANTIDAD_DINERO10.Size = new System.Drawing.Size(100, 20);
            this.CANTIDAD_DINERO10.TabIndex = 127;
            // 
            // ID_ORIGEN7
            // 
            this.ID_ORIGEN7.Location = new System.Drawing.Point(127, 46);
            this.ID_ORIGEN7.Name = "ID_ORIGEN7";
            this.ID_ORIGEN7.Size = new System.Drawing.Size(100, 20);
            this.ID_ORIGEN7.TabIndex = 109;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(124, 193);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(18, 13);
            this.label24.TabIndex = 126;
            this.label24.Text = "ID";
            // 
            // DCANTIDAD_DINERO7
            // 
            this.DCANTIDAD_DINERO7.Location = new System.Drawing.Point(233, 46);
            this.DCANTIDAD_DINERO7.Name = "DCANTIDAD_DINERO7";
            this.DCANTIDAD_DINERO7.Size = new System.Drawing.Size(100, 20);
            this.DCANTIDAD_DINERO7.TabIndex = 110;
            // 
            // ID10
            // 
            this.ID10.Location = new System.Drawing.Point(127, 210);
            this.ID10.Name = "ID10";
            this.ID10.Size = new System.Drawing.Size(100, 20);
            this.ID10.TabIndex = 125;
            // 
            // ID_DESTINO7
            // 
            this.ID_DESTINO7.Location = new System.Drawing.Point(339, 46);
            this.ID_DESTINO7.Name = "ID_DESTINO7";
            this.ID_DESTINO7.Size = new System.Drawing.Size(100, 20);
            this.ID_DESTINO7.TabIndex = 111;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(226, 135);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(107, 13);
            this.label22.TabIndex = 124;
            this.label22.Text = "CANTIDAD DINERO";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(124, 29);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(63, 13);
            this.label17.TabIndex = 112;
            this.label17.Text = "ID ORIGEN";
            // 
            // CANTIDAD_DINERO9
            // 
            this.CANTIDAD_DINERO9.Location = new System.Drawing.Point(229, 152);
            this.CANTIDAD_DINERO9.Name = "CANTIDAD_DINERO9";
            this.CANTIDAD_DINERO9.Size = new System.Drawing.Size(100, 20);
            this.CANTIDAD_DINERO9.TabIndex = 123;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(230, 29);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(107, 13);
            this.label16.TabIndex = 113;
            this.label16.Text = "CANTIDAD DINERO";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(124, 135);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(18, 13);
            this.label21.TabIndex = 122;
            this.label21.Text = "ID";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(336, 29);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 13);
            this.label12.TabIndex = 114;
            this.label12.Text = "ID DESTINO";
            // 
            // ID9
            // 
            this.ID9.Location = new System.Drawing.Point(127, 152);
            this.ID9.Name = "ID9";
            this.ID9.Size = new System.Drawing.Size(100, 20);
            this.ID9.TabIndex = 121;
            // 
            // ID_ORIGEN8
            // 
            this.ID_ORIGEN8.Location = new System.Drawing.Point(127, 103);
            this.ID_ORIGEN8.Name = "ID_ORIGEN8";
            this.ID_ORIGEN8.Size = new System.Drawing.Size(100, 20);
            this.ID_ORIGEN8.TabIndex = 115;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(336, 86);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(69, 13);
            this.label18.TabIndex = 120;
            this.label18.Text = "ID DESTINO";
            // 
            // CANTIDAD_DINERO8
            // 
            this.CANTIDAD_DINERO8.Location = new System.Drawing.Point(233, 103);
            this.CANTIDAD_DINERO8.Name = "CANTIDAD_DINERO8";
            this.CANTIDAD_DINERO8.Size = new System.Drawing.Size(100, 20);
            this.CANTIDAD_DINERO8.TabIndex = 116;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(230, 86);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(107, 13);
            this.label19.TabIndex = 119;
            this.label19.Text = "CANTIDAD DINERO";
            // 
            // ID_DESTINO8
            // 
            this.ID_DESTINO8.Location = new System.Drawing.Point(339, 103);
            this.ID_DESTINO8.Name = "ID_DESTINO8";
            this.ID_DESTINO8.Size = new System.Drawing.Size(100, 20);
            this.ID_DESTINO8.TabIndex = 117;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(124, 86);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(63, 13);
            this.label20.TabIndex = 118;
            this.label20.Text = "ID ORIGEN";
            // 
            // GRID_CUENTAS_TITULARES
            // 
            this.GRID_CUENTAS_TITULARES.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GRID_CUENTAS_TITULARES.Location = new System.Drawing.Point(412, 246);
            this.GRID_CUENTAS_TITULARES.Name = "GRID_CUENTAS_TITULARES";
            this.GRID_CUENTAS_TITULARES.Size = new System.Drawing.Size(396, 348);
            this.GRID_CUENTAS_TITULARES.TabIndex = 102;
            // 
            // GRID_CUENTAS
            // 
            this.GRID_CUENTAS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GRID_CUENTAS.Location = new System.Drawing.Point(6, 246);
            this.GRID_CUENTAS.Name = "GRID_CUENTAS";
            this.GRID_CUENTAS.Size = new System.Drawing.Size(396, 348);
            this.GRID_CUENTAS.TabIndex = 101;
            this.GRID_CUENTAS.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GRID_CUENTAS_CellContentClick);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.DimGray;
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.GRID_TITULAR_CUENTA);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.GRID_TITULARES);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1305, 608);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "TITULARES";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox4.Controls.Add(this.DNI_TITULAR2);
            this.groupBox4.Controls.Add(this.button16);
            this.groupBox4.Controls.Add(this.label39);
            this.groupBox4.Controls.Add(this.ID_CUENTA2);
            this.groupBox4.Controls.Add(this.label40);
            this.groupBox4.Controls.Add(this.DNI_TITULAR1);
            this.groupBox4.Controls.Add(this.button15);
            this.groupBox4.Controls.Add(this.label37);
            this.groupBox4.Controls.Add(this.ID_CUENTA1);
            this.groupBox4.Controls.Add(this.label38);
            this.groupBox4.Location = new System.Drawing.Point(691, 7);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(326, 228);
            this.groupBox4.TabIndex = 106;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "MANEJO CUENTA TITULAR";
            // 
            // DNI_TITULAR2
            // 
            this.DNI_TITULAR2.Location = new System.Drawing.Point(90, 96);
            this.DNI_TITULAR2.Name = "DNI_TITULAR2";
            this.DNI_TITULAR2.Size = new System.Drawing.Size(100, 20);
            this.DNI_TITULAR2.TabIndex = 76;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(6, 78);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 52);
            this.button16.TabIndex = 73;
            this.button16.Text = "eliminar cuenta";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.Button16_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(87, 79);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(75, 13);
            this.label39.TabIndex = 77;
            this.label39.Text = "DNI TITULAR";
            // 
            // ID_CUENTA2
            // 
            this.ID_CUENTA2.Location = new System.Drawing.Point(196, 96);
            this.ID_CUENTA2.Name = "ID_CUENTA2";
            this.ID_CUENTA2.Size = new System.Drawing.Size(100, 20);
            this.ID_CUENTA2.TabIndex = 74;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(193, 79);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(65, 13);
            this.label40.TabIndex = 75;
            this.label40.Text = "ID CUENTA";
            // 
            // DNI_TITULAR1
            // 
            this.DNI_TITULAR1.Location = new System.Drawing.Point(90, 37);
            this.DNI_TITULAR1.Name = "DNI_TITULAR1";
            this.DNI_TITULAR1.Size = new System.Drawing.Size(100, 20);
            this.DNI_TITULAR1.TabIndex = 71;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(6, 19);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 52);
            this.button15.TabIndex = 69;
            this.button15.Text = "añadir cuenta";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.Button15_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(87, 20);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(75, 13);
            this.label37.TabIndex = 72;
            this.label37.Text = "DNI TITULAR";
            // 
            // ID_CUENTA1
            // 
            this.ID_CUENTA1.Location = new System.Drawing.Point(196, 37);
            this.ID_CUENTA1.Name = "ID_CUENTA1";
            this.ID_CUENTA1.Size = new System.Drawing.Size(100, 20);
            this.ID_CUENTA1.TabIndex = 69;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(193, 20);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(65, 13);
            this.label38.TabIndex = 70;
            this.label38.Text = "ID CUENTA";
            // 
            // GRID_TITULAR_CUENTA
            // 
            this.GRID_TITULAR_CUENTA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GRID_TITULAR_CUENTA.Location = new System.Drawing.Point(515, 241);
            this.GRID_TITULAR_CUENTA.Name = "GRID_TITULAR_CUENTA";
            this.GRID_TITULAR_CUENTA.Size = new System.Drawing.Size(502, 348);
            this.GRID_TITULAR_CUENTA.TabIndex = 105;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox3.Controls.Add(this.DNI3);
            this.groupBox3.Controls.Add(this.label36);
            this.groupBox3.Controls.Add(this.button14);
            this.groupBox3.Controls.Add(this.DNI_ORIGEN2);
            this.groupBox3.Controls.Add(this.label32);
            this.groupBox3.Controls.Add(this.button13);
            this.groupBox3.Controls.Add(this.NOMBRE2);
            this.groupBox3.Controls.Add(this.APELLIDO2);
            this.groupBox3.Controls.Add(this.DNI2);
            this.groupBox3.Controls.Add(this.label33);
            this.groupBox3.Controls.Add(this.label34);
            this.groupBox3.Controls.Add(this.label35);
            this.groupBox3.Controls.Add(this.label31);
            this.groupBox3.Controls.Add(this.COMBO2);
            this.groupBox3.Controls.Add(this.COMBO1);
            this.groupBox3.Controls.Add(this.label30);
            this.groupBox3.Controls.Add(this.button12);
            this.groupBox3.Controls.Add(this.NOMBRE1);
            this.groupBox3.Controls.Add(this.APELLIDO1);
            this.groupBox3.Controls.Add(this.DNI1);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Location = new System.Drawing.Point(7, 7);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(677, 228);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = " CRUD TITULARES";
            // 
            // DNI3
            // 
            this.DNI3.Location = new System.Drawing.Point(90, 152);
            this.DNI3.Name = "DNI3";
            this.DNI3.Size = new System.Drawing.Size(100, 20);
            this.DNI3.TabIndex = 67;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(87, 135);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(29, 13);
            this.label36.TabIndex = 68;
            this.label36.Text = "DNI ";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(6, 135);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 52);
            this.button14.TabIndex = 66;
            this.button14.Text = "eliminar titular";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.Button14_Click);
            // 
            // DNI_ORIGEN2
            // 
            this.DNI_ORIGEN2.Location = new System.Drawing.Point(90, 94);
            this.DNI_ORIGEN2.Name = "DNI_ORIGEN2";
            this.DNI_ORIGEN2.Size = new System.Drawing.Size(100, 20);
            this.DNI_ORIGEN2.TabIndex = 64;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(87, 77);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(71, 13);
            this.label32.TabIndex = 65;
            this.label32.Text = "DNI ORIGEN";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(6, 77);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 52);
            this.button13.TabIndex = 57;
            this.button13.Text = "modificar titular";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.Button13_Click);
            // 
            // NOMBRE2
            // 
            this.NOMBRE2.Location = new System.Drawing.Point(196, 94);
            this.NOMBRE2.Name = "NOMBRE2";
            this.NOMBRE2.Size = new System.Drawing.Size(100, 20);
            this.NOMBRE2.TabIndex = 58;
            // 
            // APELLIDO2
            // 
            this.APELLIDO2.Location = new System.Drawing.Point(302, 94);
            this.APELLIDO2.Name = "APELLIDO2";
            this.APELLIDO2.Size = new System.Drawing.Size(100, 20);
            this.APELLIDO2.TabIndex = 59;
            // 
            // DNI2
            // 
            this.DNI2.Location = new System.Drawing.Point(408, 94);
            this.DNI2.Name = "DNI2";
            this.DNI2.Size = new System.Drawing.Size(100, 20);
            this.DNI2.TabIndex = 60;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(193, 77);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(54, 13);
            this.label33.TabIndex = 61;
            this.label33.Text = "NOMBRE";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(299, 77);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(59, 13);
            this.label34.TabIndex = 62;
            this.label34.Text = "APELLIDO";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(408, 78);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(26, 13);
            this.label35.TabIndex = 63;
            this.label35.Text = "DNI";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(518, 77);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(54, 13);
            this.label31.TabIndex = 56;
            this.label31.Text = "TIPO DNI";
            // 
            // COMBO2
            // 
            this.COMBO2.FormattingEnabled = true;
            this.COMBO2.Location = new System.Drawing.Point(521, 93);
            this.COMBO2.Name = "COMBO2";
            this.COMBO2.Size = new System.Drawing.Size(121, 21);
            this.COMBO2.TabIndex = 55;
            // 
            // COMBO1
            // 
            this.COMBO1.FormattingEnabled = true;
            this.COMBO1.Location = new System.Drawing.Point(409, 36);
            this.COMBO1.Name = "COMBO1";
            this.COMBO1.Size = new System.Drawing.Size(121, 21);
            this.COMBO1.TabIndex = 54;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(407, 20);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(54, 13);
            this.label30.TabIndex = 53;
            this.label30.Text = "TIPO DNI";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(6, 19);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 52);
            this.button12.TabIndex = 45;
            this.button12.Text = "añadir titular";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.Button12_Click);
            // 
            // NOMBRE1
            // 
            this.NOMBRE1.Location = new System.Drawing.Point(90, 36);
            this.NOMBRE1.Name = "NOMBRE1";
            this.NOMBRE1.Size = new System.Drawing.Size(100, 20);
            this.NOMBRE1.TabIndex = 46;
            // 
            // APELLIDO1
            // 
            this.APELLIDO1.Location = new System.Drawing.Point(196, 36);
            this.APELLIDO1.Name = "APELLIDO1";
            this.APELLIDO1.Size = new System.Drawing.Size(100, 20);
            this.APELLIDO1.TabIndex = 47;
            // 
            // DNI1
            // 
            this.DNI1.Location = new System.Drawing.Point(302, 36);
            this.DNI1.Name = "DNI1";
            this.DNI1.Size = new System.Drawing.Size(100, 20);
            this.DNI1.TabIndex = 48;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(87, 19);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(54, 13);
            this.label27.TabIndex = 49;
            this.label27.Text = "NOMBRE";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(193, 19);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(59, 13);
            this.label28.TabIndex = 50;
            this.label28.Text = "APELLIDO";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(302, 20);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(26, 13);
            this.label29.TabIndex = 51;
            this.label29.Text = "DNI";
            // 
            // GRID_TITULARES
            // 
            this.GRID_TITULARES.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GRID_TITULARES.Location = new System.Drawing.Point(7, 241);
            this.GRID_TITULARES.Name = "GRID_TITULARES";
            this.GRID_TITULARES.Size = new System.Drawing.Size(502, 348);
            this.GRID_TITULARES.TabIndex = 103;
            this.GRID_TITULARES.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GRID_TITULARES_CellClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1328, 652);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.movimientos.ResumeLayout(false);
            this.movimientos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GRID_CUENTAS_TITULARES)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GRID_CUENTAS)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GRID_TITULAR_CUENTA)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GRID_TITULARES)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox ID1;
        private System.Windows.Forms.TextBox DINERO_CUENTA1;
        private System.Windows.Forms.TextBox DINERO_DESCUBIERTO1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ID4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox ID_ORIGEN3;
        private System.Windows.Forms.TextBox DINERO_DESCUBIERTO3;
        private System.Windows.Forms.TextBox ID_DESTINO3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox DINERO_CUENTA3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox ID2;
        private System.Windows.Forms.TextBox DINERO_CUENTA2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox ID6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox ID5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox ID_DESTINO5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox DINERO_CUENTA5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox movimientos;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox CANTIDAD_DINERO11;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox ID11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.TextBox CANTIDAD_DINERO10;
        private System.Windows.Forms.TextBox ID_ORIGEN7;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox DCANTIDAD_DINERO7;
        private System.Windows.Forms.TextBox ID10;
        private System.Windows.Forms.TextBox ID_DESTINO7;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox CANTIDAD_DINERO9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox ID9;
        private System.Windows.Forms.TextBox ID_ORIGEN8;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox CANTIDAD_DINERO8;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox ID_DESTINO8;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.DataGridView GRID_CUENTAS_TITULARES;
        private System.Windows.Forms.DataGridView GRID_CUENTAS;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.TextBox NOMBRE1;
        private System.Windows.Forms.TextBox APELLIDO1;
        private System.Windows.Forms.TextBox DNI1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox COMBO1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox COMBO2;
        private System.Windows.Forms.DataGridView GRID_TITULARES;
        private System.Windows.Forms.DataGridView GRID_TITULAR_CUENTA;
        private System.Windows.Forms.TextBox DNI_ORIGEN2;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TextBox NOMBRE2;
        private System.Windows.Forms.TextBox APELLIDO2;
        private System.Windows.Forms.TextBox DNI2;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox DNI3;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox DNI_TITULAR2;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox ID_CUENTA2;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox DNI_TITULAR1;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox ID_CUENTA1;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox DNITITULAR2;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox IDCUENTA2;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox DNITITULAR1;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox IDCUENTA1;
        private System.Windows.Forms.Label label44;
    }
}

